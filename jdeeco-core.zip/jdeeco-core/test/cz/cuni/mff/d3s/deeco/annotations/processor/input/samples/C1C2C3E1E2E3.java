package cz.cuni.mff.d3s.deeco.annotations.processor.input.samples;

/**
 * Just a placeholder.
 * 
 * @author Ilias Gerostathopoulos <iliasg@d3s.mff.cuni.cz>
 * 
 */
public class C1C2C3E1E2E3 {

}
