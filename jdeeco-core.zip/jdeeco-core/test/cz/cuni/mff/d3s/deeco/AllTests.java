package cz.cuni.mff.d3s.deeco;

import org.junit.runner.RunWith;

@RunWith(DynamicSuite.class)
public class AllTests {

}
