/**
 */
package cz.cuni.mff.d3s.deeco.model.runtime.api;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Path Node Coordinator</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see cz.cuni.mff.d3s.deeco.model.runtime.meta.RuntimeMetadataPackage#getPathNodeCoordinator()
 * @model
 * @generated
 */
public interface PathNodeCoordinator extends PathNode {
} // PathNodeCoordinator
