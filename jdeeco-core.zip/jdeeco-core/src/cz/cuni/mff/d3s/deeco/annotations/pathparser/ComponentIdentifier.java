package cz.cuni.mff.d3s.deeco.annotations.pathparser;

public enum ComponentIdentifier {
	ID;
	
	public String toString() {
			return "id";
	}
}
