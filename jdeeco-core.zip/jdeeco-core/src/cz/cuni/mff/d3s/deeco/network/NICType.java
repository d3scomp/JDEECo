package cz.cuni.mff.d3s.deeco.network;

public enum NICType {
	IP,MANET;
}
