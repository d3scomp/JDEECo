/**
 * Classes that create an overlay over the individual runtime services and internals of jDEECo.
 * <p>
 * Main class: {@link cz.cuni.mff.d3s.deeco.runtime.RuntimeFrameworkBuilder}
 * </p>
 */
package cz.cuni.mff.d3s.deeco.runtime;
