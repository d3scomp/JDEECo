/**
 * Holds only DEECo annotation definitions, no business logic. 
 */
package cz.cuni.mff.d3s.deeco.annotations;