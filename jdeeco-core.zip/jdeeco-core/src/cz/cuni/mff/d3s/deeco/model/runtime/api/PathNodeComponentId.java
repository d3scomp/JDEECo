/**
 */
package cz.cuni.mff.d3s.deeco.model.runtime.api;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Path Node Component Id</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see cz.cuni.mff.d3s.deeco.model.runtime.meta.RuntimeMetadataPackage#getPathNodeComponentId()
 * @model
 * @generated
 */
public interface PathNodeComponentId extends PathNode {
} // PathNodeComponentId
