X-Y-Z-component.cf - configuration of the components in the scenario Z at the scale X, random variant Y
X-Y-Z-site.cf      - configuration of the firefighter areas in the scenario Z at the scale X, random variant Y
X-Y-Z-cfg.png      - visualisation of the scenario Z at the scale X, random variant Y